import json
from chatbot import Chatbot
from flask import Flask, request


PAGE_ACCESS_TOKEN = 'EAAMWc8F93lIBACRHnXYMfbTwQtiYaxNxkoPM0krPVqY5L5LYRU1s63VJak4rhGGM0GaH5zKDCUtZAuQ0CEy3UuXFWDlcTGa3Ljv76f7JYLEgGsVL9leZA4U3ceTejhkZBMd5pZANy9ZA1OZBMoegE9sZAZAq9pzBc58S0DZBTp1rePQZDZD'

app = Flask(__name__)


USER_POSSIBLE_RESPONSES = ["I'm sad","I'm tired of being alone."]

@app.route('/', methods=['GET', 'POST'])
def webhook():
    if request.method == 'GET':
        token = request.args.get('hub.verify_token')
        hchal = request.args.get('hub.challenge')
        if token == 'hey':
            return str(hchal)
        return 'GOOD DAY.'
    else:
        {"object":"page","entry":[{"id":"2287624768122126","time":1555475552565,"messaging":[
            {"sender":{"id":"2207457835986418"},"recipient":{"id":"2287624768122126"},"timestamp":1555475552244,"message":{"mid":"hieWpBH82qOhe7jKvrSRu4-5_3RW-vFrjppbk6Z1oYsEYRBc_xF6BTS8BEXp0tbiGKpB3TmdrfF7V4GMCT65VA","seq":403589,"text":"hi","nlp":{"entities":{"sentiment":[
                {"confidence":0.73355811297703,"value":"positive"}],"greetings":[{"confidence":0.99993050098374,"value":"true"}]}}}}]}]}
        print(request.data)
        data= json.loads(request.data)
        messaging_events = data['entry'][0]['messaging']
        chatbot = Chatbot(PAGE_ACCESS_TOKEN) 
        
        print(messaging_events)
        for message in messaging_events:
            userID = message['sender']['id']
            text_input = message['message'].get('text') # THIS IS FROM FB USER (message)
            bot_response = 'Hi, how are you today?'#AUTOMATIC RESPONSE
            
            if text_input in USER_POSSIBLE_RESPONSES:
                bot_response = 'Im a good listener'#AUTOMATIC RESPONSE
                
            
            print('Message from user ID {} -{}'.format(userID,text_input))
            chatbot.send_messaging_text(userID,bot_response)
            
        return 'GOOD DAY AGAIN'

if __name__ =='__main__':
    app.run(debug =True)



