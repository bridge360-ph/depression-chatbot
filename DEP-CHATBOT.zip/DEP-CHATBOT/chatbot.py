import requests, json

FACEBOOK_GRAPH_URL =  'https://graph.facebook.com/v3.2/me/messages'

class Chatbot(object):
    def __init__( self, access_token, api_url= FACEBOOK_GRAPH_URL):
        
        self.access_token = access_token
        self.api_url =api_url
        
    def send_messaging_text(self, psid, message, messaging_type ="RESPONSE"):
        headers = {
                'Content-Type':'application/json'
                }
        
        data = {
                
                'messaging_type':messaging_type,
                'recipient':{'id':psid},
                
#                'message':{
#                "attachment":{
#                  "type":"template",
#                  "payload":{
#                    "template_type":"button",
#                    "text":"Let me help you. Click Me.",
#                    "buttons":[
#                      {
#                        "type":"text_button",
#                        "url":"https://www.messenger.com/",
#                        "title":"URL Button",
#                        "webview_height_ratio": "full"
#                      }
#                    ]
#                  }
#                }
#              }
#                
                'message':{'text':message}
                
                
                }
        
        parameter = {'access_token':self.access_token}
        self.api_url =self.api_url
        response = requests.post(self.api_url,
                                  headers= headers,
                                  params = parameter,
                                  data = json.dumps(data))
        
        print(response.content)
        
        
    
    
chatbot = Chatbot('EAAMWc8F93lIBAD5sVhnhduCudnBXDHWrshTytypYTlgXDuo72DXKIAimpScHzeVbpnczUjYS7zUCw8AZBOtFiOvF1qTz1Kqmk8Cx6G3CcZARSnrqPNr9VaWh2jQaq3ZAmuc0JMA39gGfxJwp7NSqBtIsNSVsm5MgYcQYMub3gZDZD')        
#chatbot.send_messaging_text(2207457835986418, 'Hi, how are you today?')       
        